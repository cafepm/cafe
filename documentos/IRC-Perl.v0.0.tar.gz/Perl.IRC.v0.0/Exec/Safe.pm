package Exec::Safe;

##
##  Program execution in the local environment
##

use warnings;
use strict;

use Exporter;
use vars qw(@ISA @EXPORT);
@ISA = qw(Exporter Exec);
@EXPORT = qw/new authGetMethods authAuthenticate close/;

use IO::File;
use IPC::Open3;
use Exec;
use File::Temp qw/tempfile/;

my $debug = 1;

sub execute($) {
    my $signedCommand = shift;
    
    my ($input, $tmpName)  = tempfile();
    print "Nombre del temporario: $tmpName\n"     if $debug;
    print $input @$signedCommand;
    close $input;

    return 0   if ! _verify( $tmpName );


    return Exec::execute( _decrypt( $tmpName ) );
};

sub _verify($) {
    my $tmpName = shift;

    my $output =  IO::File->new();
    my $input  =  IO::File->new();

    print "Ejecutando GPG (verify)...\n"     if $debug;
    open3( $input, $output, $output, "gpg --verify < $tmpName");
    
    
    local $/; # enable localized slurp mode
    my $verify = <$output>;
    print "-------VERIFY-------\n$verify-------VERIFY-------\n"
        if $debug;

    return ( $verify =~ /Good signature/ms );
};

sub _decrypt($) {
    my $tmpName = shift;

    my $err =  IO::File->new();
    my $output =  IO::File->new();
    my $input  =  IO::File->new();

    print "Ejecutando GPG (decrypt)...\n"     if $debug;
    open3( $input, $output, $err, "gpg --decrypt < $tmpName");
    
    my $command = <$output>;
    print "-------DECRYPT-------\n$command-------DECRYPT-------\n"
        if $debug;
    
    $output->close();
    $input->close();
    $err->close();
    
    return $command;
};

sub _mktemp($) {
    my $data = shift;
    
    my ($input, $tmpName)  = tempfile();
    print "Nombre del temporario: $tmpName\n"     if $debug;
    print $input ( (ref $data eq "SCALAR" ) ? $$data : @$data );
    close $input;

    return $tmpName;
};

sub sign($$) {
    my ($command, $email) = @_;

    $command .= "\n";

    my $fname = _mktemp(\$command);
    
    my $err =  IO::File->new();
    my $output =  IO::File->new();
   # my $input  =  IO::File->new();

    my $exec = "gpg --armour -r $email  --sign $fname";
    print "Ejecutando GPG (sign)... '$exec' \n" 
        if $debug;
    system $exec;
    
    open ( $output, "$fname.asc" ) || die "Can't open file $fname.asc : $!";
    my @sigCommand = <$output>;
    close $output;

    print "-------SIGN-------\n@sigCommand-------SIGN-------\n"
        if $debug;
    
    $output->close();
  #  $input->close();
    $err->close();
    
    return @sigCommand;
};
1;
