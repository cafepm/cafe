README
======

Este paquete contiene los programas utilizados para ilustrar la charla sobre
protocolo IRC y Perl dada el 26 Agosto de 2006 para una Charla T�cnica
Trimestral de CaFeLUG (http://www.cafelug.org.ar).

Los archivos contenidos son :

00-events.pl : programa b�sico para un robot de IRC. Extraido de ejemplo 
               contenido en el paquete Net::IRC
               
01-command.pl : bot de IRC que interpreta los mensajes p�blicos de un canal de 
                IRC como comandos a interpretarse

02-commandSafe.pl : bot de IRC que interpreta los mensajes privados enviados
                    a el firmados por GPG

03-commandSafeSend.pl : programa que permite enviar comandos al bot anterior

Exec.pm : M�dulo b�sico para la ejecuci�n de comandos

Safe/Exec.pm : M�dulo avanzado, que permite la encripci�n y env�o de comandos
