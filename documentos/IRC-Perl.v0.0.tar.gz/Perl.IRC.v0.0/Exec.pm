package Exec;

##
##  Program execution in the local environment
##

use warnings;
use strict;

use IO::File;
use IPC::Open3;

sub execute($) {
    my $command = shift;
    my ($input, $output) = ( IO::File->new(),
                             IO::File->new() );

    my $pid = open3($input, $output, $output, $command);
    my @outText = <$output>;
    
    $input->close();
    $output->close();
    
    return ($pid, \@outText);
};


1;
